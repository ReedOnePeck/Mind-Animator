import subprocess
from tqdm import tqdm
import torch
import os
import imageio
from tqdm import tqdm
from einops import rearrange
import numpy as np
import cv2
import imageio.v3 as iio


def save_numpy_video_to_avi(numpy_video, output_folder):
    # 确保输出文件夹存在
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历每个视频
    for i in tqdm(range(numpy_video.shape[0])):
        video_frames = numpy_video[i]  # 获取第i个视频的所有帧
        video_name = f"recons_video_{i + 1}.avi"
        output_path = os.path.join(output_folder, video_name)

        # 创建VideoWriter对象
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        fps = 4  # 设置帧率
        height, width, _ = video_frames[0].shape
        video_frames_uint8 = video_frames.astype(np.uint8)
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # 将每一帧写入AVI文件
        for frame in video_frames_uint8:
            out.write(frame)

        # 释放VideoWriter对象
        out.release()


def convert_gif_to_avi(input_path, output_path):
    # 构建FFmpeg命令
    ffmpeg_cmd = [
        'ffmpeg',     # 命令
        '-i', input_path,  # 输入文件路径
        output_path    # 输出文件路径
    ]

    # 执行FFmpeg命令
    subprocess.run(ffmpeg_cmd)






"""
pred_list = []
for i  in range(1200):
    gif = iio.imread(os.path.join('/data0/home/luyizhuo/NIPS2024实验材料/Chen/sub3/sample-all', f'test{i+1}.gif'), index=None)
    _, pred = np.split(gif, 2, axis=2)
    pred_list.append(pred)

pred_list = np.stack(pred_list)
print(f'pred shape: {pred_list.shape}')

recons_path = '/data0/home/luyizhuo/NIPS2024实验材料/Chen/sub3_recons_avi/'
save_numpy_video_to_avi(pred_list, recons_path)
"""


"""
gt_list = []
pred_list = []
for i  in range(1200):
    gif = iio.imread(os.path.join('/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/Chen', f'test{i+1}.gif'), index=None)
    gt, pred = np.split(gif, 2, axis=2)
    #print(gt)
    gt_list.append(gt)
    pred_list.append(pred)

gt_list = np.stack(gt_list)
pred_list = np.stack(pred_list)
print(f'pred shape: {pred_list.shape}, gt shape: {gt_list.shape}')

gt_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/Chen/avi_file/gt_video/'
recons_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/Chen/avi_file/recons_video/'
save_numpy_video_to_avi(gt_list, gt_path)
save_numpy_video_to_avi(pred_list, recons_path)
"""



for sub_ID in [1,2,3]:
    gt_list = []
    pred_list = []
    for i in tqdm(range(304)):
        gif = iio.imread(
            os.path.join('/data0/home/luyizhuo/HCP预处理/Training_decoders/recons_results/sub0{}/'.format(sub_ID),
                         f'test_and_gt{i + 1}.gif'), index=None)
        gt, pred = np.split(gif, 2, axis=2)
        gt_list.append(gt)
        pred_list.append(pred)

    gt_list = np.stack(gt_list)
    pred_list = np.stack(pred_list)
    print(f'pred shape: {pred_list.shape}, gt shape: {gt_list.shape}')

    if sub_ID == 1:
        gt_path = '/data0/home/luyizhuo/HCP预处理/Training_decoders/recons_results/gt_avi/'
        save_numpy_video_to_avi(gt_list, gt_path)

    recons_path = '/data0/home/luyizhuo/HCP预处理/Training_decoders/recons_results/sub0{}_avi/'.format(sub_ID)
    save_numpy_video_to_avi(pred_list, recons_path)



"""

gt_list = []
pred_list = []
for i  in range(1200):
    gif = iio.imread(os.path.join('/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/recons_and_gt', f'test_and_gt{i+1}.gif'), index=None)
    gt, pred = np.split(gif, 2, axis=2)
    #print(gt)
    gt_list.append(gt)
    pred_list.append(pred)

gt_list = np.stack(gt_list)
pred_list = np.stack(pred_list)
print(f'pred shape: {pred_list.shape}, gt shape: {gt_list.shape}')

gt_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/Chen/avi_file/gt_video/'
recons_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/recons_and_gt/avi_files_for_recons/'
save_numpy_video_to_avi(gt_list, gt_path)
save_numpy_video_to_avi(pred_list, recons_path)
"""




"""
recons_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/recons_only/'
avi_path = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/sub01/recons_only/avi_files/'
for i in tqdm(range(1200)):
    input_file = recons_path + 'test{}.gif'.format(i+1)
    output_file = avi_path + "test{}.avi".format(i+1)
    convert_gif_to_avi(input_file, output_file)
"""


