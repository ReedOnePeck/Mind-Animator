import cv2
import os
import os.path as osp
from tqdm import tqdm


def img2video(img_dir, img_size, video_dir, fps):
    fourcc = cv2.VideoWriter_fourcc('M', 'J', 'P', 'G')  # opencv3.0
    videoWriter = cv2.VideoWriter(video_dir, fourcc, fps, img_size)

    for idx in sorted(os.listdir(img_dir)):
        img = osp.join(img_dir, idx)
        frame = cv2.imread(img)
        # print(frame.shape)  # h, w, c (480, 640, 3)
        videoWriter.write(frame)

    videoWriter.release()
    print('Finish changing!')

Kup_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Kupershmidt/sub3_rec_frames/folder_{}/'
Kup_avi_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Kupershmidt/sub3_rec_avi/'
fps = 4
img_size = (112, 112)

for i in tqdm(range(1,1191)):
    sub1_img_tpath = Kup_folder.format(i)
    sub1_video_path = osp.join(Kup_avi_folder, 'recons_{}.avi'.format(i))
    img2video(img_dir=sub1_img_tpath, img_size=img_size, video_dir=sub1_video_path, fps=fps)


"""

GT_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Wang/GT/video_{}'
GT_avi_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Wang/GT_avi/'

sub2_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Wang/sub3/video_{}'
sub2_avi_folder = '/data0/home/luyizhuo/NIPS2024实验材料/Wang/sub3_avi/'

fps = 4
img_size = (64, 64)

for i in tqdm(range(1,1201)):
    gt_img_tpath = GT_folder.format(i)
    gt_video_path = osp.join(GT_avi_folder, 'gt{}.avi'.format(i))
    img2video(img_dir=gt_img_tpath, img_size=img_size, video_dir=gt_video_path, fps=fps)
    sub1_img_tpath = sub2_folder.format(i)
    sub1_video_path = osp.join(sub2_avi_folder, 'sub3_{}.avi'.format(i))
    img2video(img_dir=sub1_img_tpath, img_size=img_size, video_dir=sub1_video_path, fps=fps)
"""



"""
if __name__ == '__main__':
    train_img_dir = '/nfs/nica-datashop/CC2017_for_video_reconstruction/stimuli_frames/Train/'
    test_img_dir = '/nfs/nica-datashop/CC2017_for_video_reconstruction/stimuli_frames/Test/'
    train_avi_dir = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/train_avi'
    test_avi_dir = '/nfs/diskstation/DataStation/public_dataset/CC2017_for_video_reconstruction/reconstruction_results/test_avi'

    for i in tqdm(range(1,18)):
        for j in tqdm(range(240)):
            Train_img_tpath = train_img_dir + 'seg{}_{}'.format(i + 1, j + 1)
            train_video_path = osp.join(train_avi_dir, 'output{}.avi'.format((j + 1) + 240 * i))
            fps = 4
            img_size = (512, 512)  # w, h
            img2video(img_dir=Train_img_tpath, img_size=img_size, video_dir=train_video_path, fps=fps)

    print('训练集处理完毕')

    for i in tqdm(range(5)):
        for j in tqdm(range(240)):
            Test_img_path = test_img_dir + 'test{}_{}'.format(i + 1, j + 1)
            test_video_path = osp.join(test_avi_dir, 'output{}.avi'.format((j + 1) + 240 * i))
            fps = 4
            img_size = (512, 512)  # w, h
            img2video(img_dir=Test_img_path, img_size=img_size, video_dir=test_video_path, fps=fps)

    print('测试集处理完毕')
"""

