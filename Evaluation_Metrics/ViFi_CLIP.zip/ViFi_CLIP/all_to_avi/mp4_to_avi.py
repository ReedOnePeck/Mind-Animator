import os
import cv2
from tqdm import tqdm

def convert_mp4_to_avi(input_dir, output_dir=None, codec='XVID', fps=30):
    """
    将指定目录下的所有 mp4 文件转换为 avi 格式。

    :param input_dir: 输入目录，包含 mp4 文件。
    :param output_dir: 输出目录，若为 None 则保存到 input_dir。
    :param codec: 编码器，默认使用 XVID。
    :param fps: 转换后的帧率，默认 30。
    """
    if output_dir is None:
        output_dir = input_dir

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 遍历目录下的所有 mp4 文件
    for filename in tqdm(os.listdir(input_dir)):
        if filename.endswith('.mp4'):
            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.avi")

            # 打开输入视频
            cap = cv2.VideoCapture(input_path)
            if not cap.isOpened():
                print(f"无法打开视频文件: {input_path}")
                continue

            # 获取视频属性
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fourcc = cv2.VideoWriter_fourcc(*codec)

            # 定义输出视频
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            print(f"正在处理: {input_path} -> {output_path}")

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                out.write(frame)

            cap.release()
            out.release()

    print("所有视频转换完成！")


# 示例调用
input_directory = "/nfs/diskstation/DataStation/ChangdeDu/zhaoshuangchen/CowenKeltnerEmotionalVideos/mp4_renamed"  # 替换为 mp4 文件所在目录
output_directory = "/nfs/diskstation/DataStation/ChangdeDu/zhaoshuangchen/CowenKeltnerEmotionalVideos/avi_renamed"  # 替换为输出目录，或设置为 None 保存到同一目录
convert_mp4_to_avi(input_directory, output_directory)
